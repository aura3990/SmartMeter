"""
Utility functions: PDF bill generation and WhatsApp share text.

Kept separate from app.py so the route handlers stay thin.
"""

import os
from datetime import datetime
from urllib.parse import quote

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate,
    Table,
    TableStyle,
    Paragraph,
    Spacer,
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_RIGHT

from config import Config

ACCENT = colors.HexColor("#0E7C86")
DARK = colors.HexColor("#10131A")
MUTED = colors.HexColor("#5B6472")


def generate_bill_pdf(user):
    """
    Builds a one-page PDF bill for the given User and writes it to
    Config.REPORTS_DIR. Returns the absolute file path.
    """
    os.makedirs(Config.REPORTS_DIR, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"bill_{user.room_number}_{timestamp}.pdf"
    filepath = os.path.join(Config.REPORTS_DIR, filename)

    units = user.total_units_consumed()
    amount = user.bill_amount()
    current_reading = user.latest_reading_value()
    today_str = datetime.now().strftime("%d %b %Y")

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "TitleStyle",
        parent=styles["Title"],
        textColor=DARK,
        fontSize=18,
        spaceAfter=2,
    )
    subtitle_style = ParagraphStyle(
        "SubtitleStyle",
        parent=styles["Normal"],
        textColor=MUTED,
        fontSize=10,
        alignment=TA_CENTER,
    )
    section_style = ParagraphStyle(
        "SectionStyle",
        parent=styles["Heading2"],
        textColor=ACCENT,
        fontSize=12,
        spaceBefore=14,
        spaceAfter=6,
    )
    note_style = ParagraphStyle(
        "NoteStyle",
        parent=styles["Normal"],
        textColor=MUTED,
        fontSize=8,
        alignment=TA_RIGHT,
    )

    doc = SimpleDocTemplate(
        filepath,
        pagesize=A4,
        topMargin=20 * mm,
        bottomMargin=20 * mm,
        leftMargin=20 * mm,
        rightMargin=20 * mm,
        title=f"Electricity Bill - {user.full_name}",
    )

    elements = []
    elements.append(Paragraph("Smart PG Electricity Bill Calculator", title_style))
    elements.append(Paragraph("Official Electricity Bill Summary", subtitle_style))
    elements.append(Spacer(1, 14 * mm))

    elements.append(Paragraph("Resident Details", section_style))
    resident_table = Table(
        [
            ["Name", user.full_name],
            ["Room Number", user.room_number],
            ["Mobile Number", user.mobile_number],
            ["Joining Date", user.joining_date.strftime("%d %b %Y")],
            ["Bill Generated On", today_str],
        ],
        colWidths=[55 * mm, 100 * mm],
    )
    resident_table.setStyle(
        TableStyle(
            [
                ("FONTSIZE", (0, 0), (-1, -1), 10),
                ("TEXTCOLOR", (0, 0), (0, -1), MUTED),
                ("TEXTCOLOR", (1, 0), (1, -1), DARK),
                ("FONTNAME", (0, 0), (0, -1), "Helvetica"),
                ("FONTNAME", (1, 0), (1, -1), "Helvetica-Bold"),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("LINEBELOW", (0, 0), (-1, -2), 0.5, colors.HexColor("#E2E5EA")),
            ]
        )
    )
    elements.append(resident_table)

    elements.append(Paragraph("Meter & Billing Summary", section_style))
    billing_table = Table(
        [
            ["Description", "Value"],
            ["Initial Meter Reading", f"{user.initial_reading:.2f} units"],
            ["Current Meter Reading", f"{current_reading:.2f} units"],
            ["Total Units Consumed", f"{units:.2f} units"],
            ["Rate per Unit", f"Rs. {Config.RATE_PER_UNIT}.00"],
            ["Total Bill Amount", f"Rs. {amount:.2f}"],
        ],
        colWidths=[80 * mm, 75 * mm],
    )
    billing_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), DARK),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 10),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
                ("TOPPADDING", (0, 0), (-1, -1), 7),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#E2E5EA")),
                ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#E8FBF8")),
                ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
                ("TEXTCOLOR", (0, -1), (-1, -1), ACCENT),
            ]
        )
    )
    elements.append(billing_table)

    elements.append(Spacer(1, 16 * mm))
    elements.append(
        Paragraph(
            "This is a system-generated bill from the Smart PG Electricity "
            "Bill Calculator. Formula used: Units Used = Current Reading - "
            "Initial Reading; Bill = Units Used x Rate per Unit.",
            note_style,
        )
    )

    doc.build(elements)
    return filepath


def build_whatsapp_share_text(user):
    """Returns a URL-encoded WhatsApp wa.me share text/link for the bill."""
    message = (
        f"Smart PG Electricity Bill\n"
        f"Name: {user.full_name}\n"
        f"Room: {user.room_number}\n"
        f"Initial Reading: {user.initial_reading:.2f} units\n"
        f"Current Reading: {user.latest_reading_value():.2f} units\n"
        f"Total Units: {user.total_units_consumed():.2f}\n"
        f"Bill Amount: Rs. {user.bill_amount():.2f}\n"
    )
    return f"https://wa.me/?text={quote(message)}"
