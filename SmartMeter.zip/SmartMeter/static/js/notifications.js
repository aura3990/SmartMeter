/**
 * Smart PG Electricity Bill Calculator — meter reading reminders
 * ------------------------------------------------------------------
 * Requests Notification permission once the resident is on the
 * dashboard, then checks the device clock every 30 seconds. At 07:00
 * it asks for the morning reading, and at 22:00 it asks for the final
 * (night) reading. A localStorage flag per date+slot stops the same
 * reminder firing more than once a day.
 *
 * Note: this relies on the browser tab being open (or, on supporting
 * browsers/OSes, a installed/backgrounded PWA) — there is no server
 * push involved, by design, since the requirement is a *browser*
 * notification.
 */
(function () {
  "use strict";

  var REMINDER_SLOTS = [
    { hour: 7, minute: 0, slot: "morning", title: "Morning meter reading", body: "Good morning! Please log your morning electricity meter reading." },
    { hour: 22, minute: 0, slot: "night", title: "Final meter reading", body: "Day's almost done — please log tonight's final meter reading." },
  ];

  function storageKeyFor(slot) {
    var today = new Date();
    var dateStr = today.toISOString().slice(0, 10);
    return "smartmeter_notified_" + slot + "_" + dateStr;
  }

  function alreadyNotifiedToday(slot) {
    try {
      return localStorage.getItem(storageKeyFor(slot)) === "1";
    } catch (e) {
      return false;
    }
  }

  function markNotifiedToday(slot) {
    try {
      localStorage.setItem(storageKeyFor(slot), "1");
    } catch (e) {
      /* storage unavailable, fail silently */
    }
  }

  function fireNotification(title, body) {
    if (!("Notification" in window) || Notification.permission !== "granted") return;
    var n = new Notification(title, {
      body: body,
      icon: undefined,
      tag: "smartmeter-reading-reminder",
    });
    n.onclick = function () {
      window.focus();
      window.location.href = "/add-reading";
    };
  }

  function checkReminders() {
    var now = new Date();
    REMINDER_SLOTS.forEach(function (entry) {
      if (
        now.getHours() === entry.hour &&
        now.getMinutes() === entry.minute &&
        !alreadyNotifiedToday(entry.slot)
      ) {
        fireNotification(entry.title, entry.body);
        markNotifiedToday(entry.slot);
      }
    });
  }

  function init() {
    if (!("Notification" in window)) return;

    if (Notification.permission === "default") {
      Notification.requestPermission();
    }

    // Check immediately, then poll every 30 seconds. A reading-precise
    // cron isn't possible from the client, so this catches the target
    // minute reliably without hammering the CPU.
    checkReminders();
    setInterval(checkReminders, 30 * 1000);
  }

  document.addEventListener("DOMContentLoaded", init);
})();
