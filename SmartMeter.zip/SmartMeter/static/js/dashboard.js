/**
 * Renders the "Recent Daily Consumption" line chart on the dashboard.
 */
(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    var canvas = document.getElementById("dashboardChart");
    if (!canvas) return;

    fetch("/api/chart-data")
      .then(function (res) {
        return res.json();
      })
      .then(function (data) {
        var daily = data.daily || { labels: [], data: [] };

        if (!daily.labels.length) {
          canvas.classList.add("d-none");
          var emptyEl = document.getElementById("dashboardChartEmpty");
          if (emptyEl) emptyEl.classList.remove("d-none");
          return;
        }

        new Chart(canvas.getContext("2d"), {
          type: "line",
          data: {
            labels: daily.labels,
            datasets: [
              {
                label: "Units consumed",
                data: daily.data,
                borderColor: "#21e6c1",
                backgroundColor: "rgba(33, 230, 193, 0.15)",
                pointBackgroundColor: "#21e6c1",
                tension: 0.35,
                fill: true,
              },
            ],
          },
          options: {
            responsive: true,
            plugins: {
              legend: { labels: { color: "#8ca0ae" } },
            },
            scales: {
              x: { ticks: { color: "#8ca0ae" }, grid: { color: "rgba(148,197,210,0.08)" } },
              y: { ticks: { color: "#8ca0ae" }, grid: { color: "rgba(148,197,210,0.08)" }, beginAtZero: true },
            },
          },
        });
      })
      .catch(function () {
        /* Chart is non-critical; fail quietly if the API call errors */
      });
  });
})();
