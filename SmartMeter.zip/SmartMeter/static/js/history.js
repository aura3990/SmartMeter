/**
 * Renders the daily / weekly / monthly consumption chart on the
 * history page, switching datasets when a tab is clicked.
 */
(function () {
  "use strict";

  var chartInstance = null;
  var chartData = null;

  var COLORS = {
    daily: "#21e6c1",
    weekly: "#8b7cfa",
    monthly: "#ffb454",
  };

  function renderChart(range) {
    var canvas = document.getElementById("historyChart");
    var emptyEl = document.getElementById("historyChartEmpty");
    if (!canvas || !chartData) return;

    var dataset = chartData[range] || { labels: [], data: [] };

    if (!dataset.labels.length) {
      canvas.classList.add("d-none");
      if (emptyEl) emptyEl.classList.remove("d-none");
      if (chartInstance) {
        chartInstance.destroy();
        chartInstance = null;
      }
      return;
    }

    canvas.classList.remove("d-none");
    if (emptyEl) emptyEl.classList.add("d-none");

    if (chartInstance) {
      chartInstance.destroy();
    }

    var color = COLORS[range] || COLORS.daily;

    chartInstance = new Chart(canvas.getContext("2d"), {
      type: "bar",
      data: {
        labels: dataset.labels,
        datasets: [
          {
            label: "Units consumed",
            data: dataset.data,
            backgroundColor: color + "cc",
            borderRadius: 6,
            maxBarThickness: 38,
          },
        ],
      },
      options: {
        responsive: true,
        plugins: {
          legend: { labels: { color: "#8ca0ae" } },
        },
        scales: {
          x: { ticks: { color: "#8ca0ae" }, grid: { display: false } },
          y: { ticks: { color: "#8ca0ae" }, grid: { color: "rgba(148,197,210,0.08)" }, beginAtZero: true },
        },
      },
    });
  }

  function wireTabs() {
    var tabs = document.querySelectorAll("#chartTabs .nav-link");
    tabs.forEach(function (tab) {
      tab.addEventListener("click", function () {
        tabs.forEach(function (t) {
          t.classList.remove("active");
        });
        tab.classList.add("active");
        renderChart(tab.dataset.range);
      });
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    var canvas = document.getElementById("historyChart");
    if (!canvas) return;

    wireTabs();

    fetch("/api/chart-data")
      .then(function (res) {
        return res.json();
      })
      .then(function (data) {
        chartData = data;
        renderChart("daily");
      })
      .catch(function () {
        var emptyEl = document.getElementById("historyChartEmpty");
        canvas.classList.add("d-none");
        if (emptyEl) emptyEl.classList.remove("d-none");
      });
  });
})();
