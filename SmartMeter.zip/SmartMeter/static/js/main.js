/**
 * Smart PG Electricity Bill Calculator — shared front-end behaviour
 * Handles: active nav link state, WhatsApp share button, and a small
 * count-up animation for numeric stat values on first paint.
 */
(function () {
  "use strict";

  // ---- Highlight the active nav link based on current path -----------
  function highlightActiveNav() {
    var path = window.location.pathname;
    document.querySelectorAll(".smartmeter-nav .nav-link").forEach(function (link) {
      try {
        var linkPath = new URL(link.href).pathname;
        if (linkPath === path) {
          link.classList.add("active");
        }
      } catch (e) {
        /* ignore malformed hrefs */
      }
    });
  }

  // ---- WhatsApp share button (present on the dashboard) ---------------
  function wireWhatsappShare() {
    var btn = document.getElementById("whatsappShareBtn");
    if (!btn) return;

    btn.addEventListener("click", function () {
      btn.disabled = true;
      var originalHtml = btn.innerHTML;
      btn.innerHTML = '<i class="bi bi-hourglass-split me-1"></i>Preparing...';

      fetch("/bill/whatsapp-link")
        .then(function (res) {
          if (!res.ok) throw new Error("Could not build share link");
          return res.json();
        })
        .then(function (data) {
          window.open(data.url, "_blank", "noopener");
        })
        .catch(function () {
          alert("Could not prepare the WhatsApp share link. Please try again.");
        })
        .finally(function () {
          btn.disabled = false;
          btn.innerHTML = originalHtml;
        });
    });
  }

  // ---- Gentle count-up animation for .stat-value numeric content ------
  function animateStatValues() {
    document.querySelectorAll(".stat-card .stat-value").forEach(function (el) {
      var text = el.textContent.trim();
      var match = text.match(/^([^\d]*)([\d.,]+)([^\d]*)$/);
      if (!match) return;

      var prefix = match[1];
      var numberText = match[2].replace(/,/g, "");
      var suffix = match[3];
      var target = parseFloat(numberText);
      if (isNaN(target)) return;

      var decimals = numberText.includes(".") ? numberText.split(".")[1].length : 0;
      var duration = 700;
      var start = null;

      function step(timestamp) {
        if (!start) start = timestamp;
        var progress = Math.min((timestamp - start) / duration, 1);
        var current = target * progress;
        el.textContent = prefix + current.toFixed(decimals) + suffix;
        if (progress < 1) {
          window.requestAnimationFrame(step);
        } else {
          el.textContent = prefix + target.toFixed(decimals) + suffix;
        }
      }
      window.requestAnimationFrame(step);
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    highlightActiveNav();
    wireWhatsappShare();
    animateStatValues();
  });
})();
