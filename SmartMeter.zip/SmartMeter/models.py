"""
Database models for Smart PG Electricity Bill Calculator.

Two tables are created automatically on first run:

  users     -> one row per PG resident (registration data + auth)
  readings  -> one row per (user, date), holding the morning and
               night meter readings for that day

The relationship is a standard one-to-many: a User has many Readings.
"""

from datetime import datetime

from werkzeug.security import generate_password_hash, check_password_hash

from extensions import db
from config import Config


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(120), nullable=False)
    room_number = db.Column(db.String(20), nullable=False)
    mobile_number = db.Column(db.String(15), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    joining_date = db.Column(db.Date, nullable=False)
    initial_reading = db.Column(db.Float, nullable=False, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    readings = db.relationship(
        "Reading",
        backref="user",
        lazy=True,
        cascade="all, delete-orphan",
        order_by="Reading.date",
    )

    # ---- auth helpers -------------------------------------------------
    def set_password(self, raw_password):
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password):
        return check_password_hash(self.password_hash, raw_password)

    # ---- billing / consumption helpers --------------------------------
    def latest_reading_value(self):
        """
        Returns the most recent meter reading value entered by the user,
        looking at night readings first, then morning, across the most
        recent dated entry. Falls back to the initial reading if the
        user has not logged anything yet.
        """
        ordered = sorted(self.readings, key=lambda r: r.date, reverse=True)
        for r in ordered:
            if r.night_reading is not None:
                return r.night_reading
            if r.morning_reading is not None:
                return r.morning_reading
        return self.initial_reading

    def total_units_consumed(self):
        units = self.latest_reading_value() - self.initial_reading
        return round(max(units, 0), 2)

    def bill_amount(self):
        return round(self.total_units_consumed() * Config.RATE_PER_UNIT, 2)

    def reading_for_date(self, the_date):
        for r in self.readings:
            if r.date == the_date:
                return r
        return None


class Reading(db.Model):
    __tablename__ = "readings"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    date = db.Column(db.Date, nullable=False, index=True)
    morning_reading = db.Column(db.Float, nullable=True)
    night_reading = db.Column(db.Float, nullable=True)
    daily_consumption = db.Column(db.Float, nullable=True)

    __table_args__ = (
        db.UniqueConstraint("user_id", "date", name="uq_user_date"),
    )

    def recompute_daily_consumption(self):
        """Daily consumption = night reading - morning reading, only
        when both slots for the day have been filled in."""
        if self.morning_reading is not None and self.night_reading is not None:
            self.daily_consumption = round(
                max(self.night_reading - self.morning_reading, 0), 2
            )
        else:
            self.daily_consumption = None
