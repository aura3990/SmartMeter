"""
Smart PG Electricity Bill Calculator
-------------------------------------
Central configuration for the Flask application.

All tunable constants live here so the rest of the codebase never
hard-codes a magic number. Change RATE_PER_UNIT if your PG's per-unit
electricity charge changes.
"""

import os
from werkzeug.security import generate_password_hash

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    # Flask
    SECRET_KEY = os.environ.get("SECRET_KEY", "smart-pg-dev-secret-key-change-me")

    # Database (SQLite file lives at the project root, matching the
    # required file structure: SmartMeter/database.db)
    SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(BASE_DIR, "database.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Billing
    RATE_PER_UNIT = 10  # ₹ per unit, fixed as per requirement

    # Where generated PDF bills are written before being sent to the user
    REPORTS_DIR = os.path.join(BASE_DIR, "reports")

    # Admin login. In a real deployment, set ADMIN_USERNAME / ADMIN_PASSWORD
    # as environment variables instead of using these defaults.
    ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")
    ADMIN_PASSWORD_HASH = generate_password_hash(
        os.environ.get("ADMIN_PASSWORD", "admin123")
    )
