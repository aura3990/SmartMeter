"""
Shared Flask extension instances.

Kept in their own module so app.py, models.py and other files can all
import the same `db` object without circular-import problems.
"""

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
