# Smart PG Electricity Bill Calculator

A production-ready Flask web app for PG (paying-guest) accommodations to track
per-room electricity meter readings, calculate bills, and give wardens an
admin overview.

## Tech stack
Python · Flask · Flask-SQLAlchemy · SQLite · Bootstrap 5 · Chart.js · vanilla
JavaScript · ReportLab (PDF generation)

## Project structure
```
SmartMeter/
├── app.py                 # Flask app & all routes
├── config.py               # Settings: secret key, DB URI, billing rate, admin creds
├── extensions.py           # Shared SQLAlchemy() instance
├── models.py               # User and Reading SQLAlchemy models
├── utils.py                 # PDF bill generator + WhatsApp share text builder
├── requirements.txt
├── database.db              # Created automatically on first run
├── templates/                # Jinja2 HTML templates
├── static/
│   ├── css/style.css         # Dark theme / glassmorphism design system
│   ├── js/                   # main.js, dashboard.js, history.js, notifications.js
│   └── images/
└── reports/                  # Generated PDF bills are written here
```

## Setup

```bash
cd SmartMeter
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

The app runs at `http://127.0.0.1:5000`. `database.db` and its tables
(`users`, `readings`) are created automatically on first run — there's
nothing to migrate by hand.

## Default admin login

| Username | Password |
|----------|----------|
| `admin`  | `admin123` |

Change these before any real deployment by setting the `ADMIN_USERNAME` and
`ADMIN_PASSWORD` environment variables (see `config.py`). Also replace
`SECRET_KEY` with a long random value in production.

## How billing works

```
Units Used = Current Meter Reading − Initial Meter Reading
Bill        = Units Used × ₹10 (RATE_PER_UNIT in config.py)
```

"Current Meter Reading" is always the most recently logged reading (night
reading takes priority over morning reading for the same day).

## Key flows

- **Register** — full name, room number, 10-digit mobile number, password,
  joining date, and initial meter reading.
- **Login** — mobile number + password, session-based.
- **Add Reading** — one morning entry and one night entry per calendar day;
  the server rejects a second entry for a slot that's already filled, and
  rejects a reading lower than the last one recorded.
- **History** — full table of readings plus Daily / Weekly / Monthly Chart.js
  graphs (toggle with the pill tabs above the chart).
- **PDF Bill** — `/bill/download` streams a generated PDF; copies are also
  saved under `reports/`.
- **WhatsApp Share** — the dashboard's Share button opens `wa.me` with a
  pre-filled bill summary.
- **Browser Notifications** — once a resident grants permission on the
  dashboard, the browser reminds them at 7:00 AM and 10:00 PM (device local
  time) to log a reading. This requires the tab to be open and only works
  per-device, since there's no push server involved.
- **Admin Panel** — `/admin/login` shows total users, total rooms, total
  revenue, highest/lowest consumer, every resident's details, and the full
  reading history across all residents.

## Notes for going to production

- Swap the default `SECRET_KEY` and admin credentials for real secrets.
- Put the app behind a WSGI server (gunicorn/uwsgi) instead of `app.run()`.
- SQLite is fine for a single PG; for multiple properties or higher
  concurrency, point `SQLALCHEMY_DATABASE_URI` at Postgres/MySQL instead.
